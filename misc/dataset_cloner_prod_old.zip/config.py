# Luzmo Credentials & URLs
LUZMO_API_KEY = "e21b4908-5343-4bcf-af9b-b5091cbf171b"
LUZMO_TOKEN = "qrFvLnublI4IDVnOh8Aorwch6bJstMeJCEP5NwEwUY3CDxweRajzMkH0100toCwQVmVrI0CGKgBPfRVV7h2o5eOuO71xQqrkKVTg2XQsyOBz0o8VXwGm3Lxs2Jmcp7l1m0la992jqSwbIlaYl4pr3J"

luzmo_base_url = "https://api.us.cumul.io/0.1.0/"
luzmo_endpoints = {
    "column_url": luzmo_base_url + "column",
    "securable_url": luzmo_base_url + "securable",
    "hierarchy_url": luzmo_base_url + "hierarchy"
}