import requests
import json

# Define API endpoint
api_url = 'https://api.us.cumul.io/0.1.0/securable'

def createDashboard(key, token, dashboardName, contents, css):
    # Define request payload
    payload = {
        "action": "create",
        "key": key,
        "token": token,
        "version": "0.1.0",
        "properties": {
            "type": "dashboard",
            "name": {
            "en": dashboardName
            },
        "contents": contents,
        "css": css
        }
    }
    # Send API request
    response = requests.post(api_url, json=payload)

    # Check response status code
    if response.status_code == 200:
        print("Successfully Created the dashboard!")
        response_json = response.json()
        print("Response:", response_json)
        dash_id = response_json['id']
        return dash_id
    else:
        # Handle API error
        print('API request failed with status code:', response.status_code)
