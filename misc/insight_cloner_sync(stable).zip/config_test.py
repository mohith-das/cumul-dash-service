# Insights URLs and Credentials
insights_dash_url = "https://test-insights-service.sarasanalytics.com/dashboard"
check_insights_dash_link = (
    "https://test-insights-service.sarasanalytics.com/dashboard/by-company/"
)
firebase_insights_login_payload = {
    "email": "codax45063@lubde.com",
    "password": "P@ss1234",
    "returnSecureToken": True,
}
firebase_login_api_key = "AIzaSyBb_9IO142S5YK3VSOEfqrAQoOaawk9c78"
firebase_insights_login_url = (
    "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword"
)

# Luzmo Credentials & URLs
LUZMO_API_KEY = "e21b4908-5343-4bcf-af9b-b5091cbf171b"
LUZMO_TOKEN = "qrFvLnublI4IDVnOh8Aorwch6bJstMeJCEP5NwEwUY3CDxweRajzMkH0100toCwQVmVrI0CGKgBPfRVV7h2o5eOuO71xQqrkKVTg2XQsyOBz0o8VXwGm3Lxs2Jmcp7l1m0la992jqSwbIlaYl4pr3J"
LUZMO_BQ_ACCOUNT_ID = "9fc5cece-932f-43fc-b501-cd71bed4ab32"

luzmo_base_url = "https://api.us.cumul.io/0.1.0/"
luzmo_endpoints = {
    "acceleration_url": luzmo_base_url + "acceleration",
    "dataprovider_url": luzmo_base_url + "dataprovider",
    "integration_url": luzmo_base_url + "integration",
    "securable_url": luzmo_base_url + "securable",
}

# Dashboard Service Resources
config_table_id = "solutionsdw.insights_config.insights_dashboardService_config"
logger_table_id = "solutionsdw.insights_config.dash_service_logger"
