# Insights URLs and Credentials
insights_dash_url = "https://insights-service.sarasanalytics.com/dashboard"
check_insights_dash_link = (
    "https://insights-service.sarasanalytics.com/dashboard/by-company/"
)
firebase_insights_login_payload = {
    "email": "kalkidan.dagnu@sarasanalytics.com",
    "password": "Pioneer@12345!",
    "returnSecureToken": True,
}
firebase_login_api_key = "AIzaSyAUSCztGhQ4t2GcIO-ygRPabnsYzTr5w8Y"
firebase_insights_login_url = (
    "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword"
)

# Luzmo Credentials & URLs
LUZMO_API_KEY = "e21b4908-5343-4bcf-af9b-b5091cbf171b"
LUZMO_TOKEN = "qrFvLnublI4IDVnOh8Aorwch6bJstMeJCEP5NwEwUY3CDxweRajzMkH0100toCwQVmVrI0CGKgBPfRVV7h2o5eOuO71xQqrkKVTg2XQsyOBz0o8VXwGm3Lxs2Jmcp7l1m0la992jqSwbIlaYl4pr3J"
LUZMO_BQ_ACCOUNT_ID = "17be4d43-97f3-4838-85fc-8d4af0c190bf"

luzmo_base_url = "https://api.us.cumul.io/0.1.0/"
luzmo_endpoints = {
    "acceleration_url": luzmo_base_url + "acceleration",
    "dataprovider_url": luzmo_base_url + "dataprovider",
    "integration_url": luzmo_base_url + "integration",
    "securable_url": luzmo_base_url + "securable",
}

# Dashboard Service Resources
config_table_id = "insightsprod.insights_config.insights_dashboardService_config_prod"
logger_table_id = "insightsprod.insights_config.dash_service_logger"

#Insights Dataset Cloner Assets
TOPIC = 'insights_dataset_cloner'