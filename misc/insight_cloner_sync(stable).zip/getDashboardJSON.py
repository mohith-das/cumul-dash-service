import requests
import json

# Define API endpoint
api_url = 'https://api.us.cumul.io/0.1.0/securable'

def getDashboardJSON(key, token, dashboardId):
    # Define request payload
    payload = {
      "action": "get",
      "key": key, 
      "token": token,
      "version": "0.1.0",
      "find": {
        "where": {
          "id": dashboardId,
          "type": "dashboard"
        },
        "include": [
          {
            "model": "Securable",
            "as": "Datasets",
            "include": [
                {
            "attributes": [
              "id",
              "name"
            ],
            "model": "Column",
            "jointype": "inner"
          }
            ]
          }
        ]
      }
    }
    # Send API request
    response = requests.post(api_url, json=payload)

    # Check response status code
    if response.status_code == 200:
        # Parse response JSON data
        data = json.loads(response.text)
        # Process API response data
        print(data)

        # with open(f'{dashboardId}.json', 'w') as f:
        #     json.dump(data, f)

        return data
    else:
        # Handle API error
        print('API request failed with status code:', response.status_code)
