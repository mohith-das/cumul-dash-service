import json
from getDashboardJSON import getDashboardJSON
from getDatasetJSON import getDatasetJSON
from createDashboard import createDashboard


def createDashboardAPI(dashboardkey, dashboardtoken, dashboardId, datasetkey, datasettoken, datasetIdMap, dashboardName):
    # Get the JSON file
    json1 = getDashboardJSON(dashboardkey, dashboardtoken, dashboardId)
    # Convert JSON object to string
    json_string = json.dumps(json1)

    datasetMapper = {}
    idx=0
    for dataset in json1["rows"][0]["datasets"]:
        datasetMapper[dataset["id"]] = idx
        idx+=1

    for oId, nId in datasetIdMap.items():
        json2 = getDatasetJSON(datasetkey, datasettoken, nId)
        whichi = datasetMapper[oId]

        oldDatasetIds = {}
        for i in range(len(json1["rows"][0]["datasets"][whichi]["columns"])):
            oldDatasetIds[str(json1["rows"][0]["datasets"][whichi]["columns"][i]["name"]["en"]).lower()] = json1["rows"][0]["datasets"][whichi]["columns"][i]["id"]
        print(oldDatasetIds)

        newDatasetIds = {}
        for i in range(len(json2["rows"][0]["columns"])):
            newDatasetIds[str(json2["rows"][0]["columns"][i]["name"]["en"]).lower()] = json2["rows"][0]["columns"][i]["id"]
        print(newDatasetIds)

        idMapper = {}
        idMapper[json1["rows"][0]["datasets"][whichi]["id"]] = nId
        # idMapper["AlwaysPrepared"] = "KagedMuscle"
        # idMapper["AtlasSeller"] = "KagedMuscle"
        # idMapper["adspend"] = idMapper["spend"]
        # idMapper["impressions"] = idMapper["impression"]


        for k1, v1 in oldDatasetIds.items():
            idMapper[v1] = newDatasetIds.get(k1)
        # print(idMapper)

        # Replace a substring within the string if it is found
        for key, value in idMapper.items():
            if value == None:
                continue
            if key in json_string:
                json_string = json_string.replace(key, value)
        print(idMapper)


    json_data = json.loads(json_string)
    # Save modified JSON object to local file
    # with open(f'modified_{dashboardId}.json', 'w') as f:
    #     json.dump(json_data, f)

    contents = json_data["rows"][0]["contents"]
    css = json_data["rows"][0]["css"]
    dash_id = createDashboard(datasetkey, datasettoken, dashboardName, contents, css)
    return dash_id

